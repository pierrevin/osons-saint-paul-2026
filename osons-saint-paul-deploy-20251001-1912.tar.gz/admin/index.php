<?php
// Redirection vers l'interface d'administration
header('Location: /admin/pages/schema_admin.php');
exit;
?>
