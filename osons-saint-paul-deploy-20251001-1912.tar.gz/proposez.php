<?php
// Définir le chemin racine pour que les includes fonctionnent
define('ROOT_PATH', __DIR__);

// Inclure le formulaire de proposition citoyenne
require_once ROOT_PATH . '/forms/proposition-citoyenne.php';
?>

